import { CommonModule } from '@angular/common';
import { Component, Input, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-card',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './card.component.html',
  styleUrl: './card.component.scss'
})
export class CardComponent {

  cardNumber!: number;
  expirationDate: string = '';
  cvv!: number;

  constructor() { }

  // Method to handle form submission
  onSubmit() {
    // Handle form submission logic here
    console.log('Form submitted with card details:', this.cardNumber, this.expirationDate, this.cvv);
  }
}