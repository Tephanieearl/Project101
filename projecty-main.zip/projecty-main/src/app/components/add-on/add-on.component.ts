
import { Component, Input, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';



@Component({
  selector: 'app-add-on',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './add-on.component.html',
  styleUrl: './add-on.component.scss'
})
export class AddOnComponent {

  @Input() addOn: any;

}
