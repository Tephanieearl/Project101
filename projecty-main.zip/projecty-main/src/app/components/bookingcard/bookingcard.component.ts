import { CommonModule } from '@angular/common';
import { Component, Input, ElementRef, AfterViewInit, Renderer2 } from '@angular/core';

@Component({
  selector: 'app-bookingcard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bookingcard.component.html',
  styleUrl: './bookingcard.component.scss'
})
export class BookingcardComponent{

  @Input() categoryData: any;

  constructor() { }

  truncateDescription(description: string): string {
    return description.length > 62 ? description.substring(0, 62) + '...' : description;
  }
  shouldReduceTitleFontSize(title: string): boolean {
    return title.length > 23;
  }
}