import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingcardComponent } from './bookingcard.component';

describe('BookingcardComponent', () => {
  let component: BookingcardComponent;
  let fixture: ComponentFixture<BookingcardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BookingcardComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BookingcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
