import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-details',
  standalone: true,
  imports: [],
  templateUrl: './blog-details.component.html',
  styleUrl: './blog-details.component.scss'
})
export class BlogDetailsComponent {
  constructor() { }

  adjustImage(image: HTMLImageElement): void {
    if (image.naturalWidth < image.naturalHeight) {
      image.style.objectFit = 'cover'; // Apply cover cropping for portrait images
      image.style.height = 'auto'; // Allow height to adjust to maintain aspect ratio
      image.style.width = '100%'; // Make image full width
    }
  }
}
