import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-popularcard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './popularcard.component.html',
  styleUrl: './popularcard.component.scss'
})
export class PopularcardComponent {
  @Input() popularCards: any;

  truncateDescription(description: string): string {
    return description.length > 55 ? description.substring(0, 55) + '...' : description;
  }

}
