import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

interface Faq {
  question: string;
  answer: string;
  isOpen: boolean;
}

@Component({
  selector: 'app-faqs',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './faqs.component.html',
  styleUrl: './faqs.component.scss',
})
export class FaqsComponent {
  faqs: Faq[] = [
    {
      question: 'Do I need experience to become a local guide?',
      answer:
      'Nope! Whether you\'re a seasoned pro or just passionate about your area, you\'re welcome to join us. We\'re all about sharing the love for your city or region!',
      isOpen: false,
    },
    {
      question: 'What if I need to cancel a tour?',
      answer:
        'Life happens! If you need to cancel, just let the travelers know ASAP and reach out to us for assistance. We\'re here to help you navigate any bumps in the road.',
      isOpen: false,
    },
    {
      question: 'How do I receive booking requests?',
      answer:
        'When travelers are interested in your tour, they\'ll send you a booking request. You\'ll get a notification with all the info, so you can review and confirm if it fits your schedule.',
      isOpen: false,
    },
    {
      question: 'What support do you offer to local guides?',
      answer:
        'We\'ve got your back! From helpful guides and tips to assistance with bookings and inquiries, our support team is here to make your journey as smooth as possible.',
      isOpen: false,
    },
    {
      question: 'How do I collect reviews from travelers?',
      answer:
        'After the tour, kindly ask your guests to leave a review on our platform. Their feedback helps build trust and lets other travelers know how awesome you are!',
      isOpen: false,
    },
    {
      question: 'How do I get paid for my tours?',
      answer:
        'Getting paid is hassle-free! Once the tour is done, your earnings will be securely processed through our platform and sent directly to your account.',
      isOpen: false,
    },
    // Add more FAQ items as needed
  ];

  toggleFaq(index: number) {
    this.faqs[index].isOpen = !this.faqs[index].isOpen;
  }
}
