import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-travelercard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './travelercard.component.html',
  styleUrl: './travelercard.component.scss'
})
export class TravelercardComponent {
  @Input() travelerCards: any;

}
