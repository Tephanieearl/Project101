import { Component, AfterViewInit, ViewChild, ElementRef, PLATFORM_ID, Inject, Input,} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import Glide from '@glidejs/glide';
import { RouterModule } from '@angular/router';


@Component({
  selector: 'app-carousel',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
})
export class CarouselComponent implements AfterViewInit {

  @Input() cards: any[] = [];


  getCardBackgroundStyle(imageUrl: string): any {
    return {
      'background-image': `url(${imageUrl})`,
      'background-size': 'cover', // Optional: Adjust background size as needed
      'background-position': 'center', // Optional: Adjust background position as needed
    };
  }

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
  }

  ///////

  @ViewChild('glideContainer') glideContainer!: ElementRef;


  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      const glideConfig = {
        type: 'carousel' as const,
        focusAt: 'center',
        perView: 4,
        breakpoints: {
          1024: { perView: 3 },
          640: { perView: 2 },
          630: { perView: 2 }
        }
      };

      if (this.glideContainer) {
        const glide = new Glide(this.glideContainer.nativeElement, glideConfig);
        glide.mount();
      } 
    }
  }
}