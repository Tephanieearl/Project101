import { CommonModule } from '@angular/common';
import { Component, Input, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import Glide from '@glidejs/glide'

@Component({
  selector: 'app-reviewcard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './reviewcard.component.html',
  styleUrl: './reviewcard.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ReviewcardComponent implements OnInit {
  @Input() reviews: any;

  constructor() { }

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      const glide07 = new Glide('.glide-08', {
        type: 'carousel',
        focusAt: 1,
        animationDuration: 4000,
        autoplay: 4500,
        rewind: true,
        perView: 2,
        gap: 48,
        breakpoints: {
          1024: {
            perView: 2
          },
          640: {
            perView: 1
          }
        }
      });

      glide07.mount();
    }
  }
}
