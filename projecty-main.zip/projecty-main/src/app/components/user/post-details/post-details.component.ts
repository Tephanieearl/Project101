import { Component, OnInit } from '@angular/core';
import { TravelercardComponent } from '../../travelercard/travelercard.component';
import { TravelercardService } from '../../../services/travelcard-service/travelercard.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-post-details',
  standalone: true,
  imports: [TravelercardComponent, CommonModule],
  templateUrl: './post-details.component.html',
  styleUrl: './post-details.component.scss'
})
export class PostDetailsComponent {

  travelerCardsData = [
    {
      locationName: 'Nusugbu, Batangas',
      destinationName: 'Fortune Island',
      categories: ['Adventure', 'Sea'],
      imageUrl: 'https://images.unsplash.com/photo-1505370632420-d1e987d5c75c',
      authorName: 'Ivan Torres',
      avatar: 'https://images.unsplash.com/profile-1598022349778-ee6869101631image',
      likesCount: 22,
      commentsCount: 20,
    },
  ];
}
