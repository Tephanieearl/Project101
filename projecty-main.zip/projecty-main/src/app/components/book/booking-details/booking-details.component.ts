import { CommonModule } from '@angular/common';
import { Component, ElementRef } from '@angular/core';

import { PaginationComponent } from '../../pagination/pagination.component';
import { RouterModule } from '@angular/router';
import { AddOnComponent } from '../../add-on/add-on.component';
import { ReviewcardComponent } from '../../reviewcard/reviewcard.component';
import { ReviewdetailsComponent } from '../../reviewdetails/reviewdetails.component';
import { FormsModule } from '@angular/forms';



@Component({
  selector: 'app-booking-details',
  standalone: true,
    imports: [CommonModule, ReviewcardComponent, PaginationComponent, RouterModule, AddOnComponent, ReviewdetailsComponent, FormsModule],
  templateUrl: './booking-details.component.html',
  styleUrl: './booking-details.component.scss'
})
export class BookingDetailsComponent {
// Define array of image URLs
imageUrls: string[] = [
  '/assets/categories/adventure/image1.jpg',
  '/assets/categories/adventure/image2.jpg',
  '/assets/categories/adventure/image3.jpg',
  '/assets/categories/adventure/image4.jpg',
  '/assets/categories/adventure/image5.jpg',
];


// Define the initial featured image URL
featuredImageUrl: string = this.imageUrls[0]; // Set the initial featured image from the array
// Function to change the featured image
changeFeaturedImage(newImageUrl: string): void {
  this.featuredImageUrl = newImageUrl;
  
}


showDescriptionFlag: boolean = true;
  showAboutFlag: boolean = false;

  showDescription() {
    this.showDescriptionFlag = true;
    this.showAboutFlag = false;
  }

  showAbout() {
    this.showDescriptionFlag = false;
    this.showAboutFlag = true;
  }

  selectedSection: string = 'description';

  selectSection(section: string) {
    this.selectedSection = section;
  }

  //Add On Data
  addOnsDetails = [
    {
      name: "Photography Package",
      desc: "Capture the mesmerizing beauty of Mount Pulag with a professional photographer."
    },
    {
      name: "Camping Gear Rental",
      desc: "Experience the thrill of camping under the stars on Mount Pulag's summit."
    },
  ]


  reviewsData = [
    {
      comment: "Wind-ui, is probably one of the best libraries I've came across. Good looking, easy to use and above all super accessible.",
      rating: 5,
      avatar: "https://i.pravatar.cc/40?img=11",
      userName: "Bill Gates",
      date: "March 08, 2024"
    },
    {
      comment: "Wind-ui, is probably one of the best libraries I've came across. Good looking, easy to use and above all super accessible.",
      rating: 4,
      avatar: "https://i.pravatar.cc/40?img=11",
      userName: "Test 12",
      date: "March 08, 2024"
    },
    // Add more review objects as needed
  ];

  constructor(private elementRef: ElementRef) {}

  scrollToElement(id: string): void {
    const element = this.elementRef.nativeElement.querySelector('#' + id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }


  ///Contact Me
  userInput: string = ''; // Property to store user input
  chatMessages: string[] = []; // Array to store chat messages

  sendMessage() {
    if (this.userInput.trim() !== '') { // Check if the user input is not empty
      this.chatMessages.push(this.userInput); // Add the user input to the chat messages array
      this.userInput = ''; // Clear the input field after sending
    }
  }
}