import { Component, Input } from '@angular/core';
import {CdkStepper, CdkStepperModule} from '@angular/cdk/stepper';
import { CommonModule } from '@angular/common';

import { CardComponent } from '../../card/card/card.component';



@Component({
  selector: 'app-hire-me',
  standalone: true,
  imports: [CdkStepperModule, CdkStepper, CommonModule, CardComponent,],

  templateUrl: './hire-me.component.html',
  styleUrl: './hire-me.component.scss'
})
export class HireMeComponent {


}