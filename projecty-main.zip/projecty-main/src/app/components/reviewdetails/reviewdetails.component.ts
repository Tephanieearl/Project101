import { CommonModule } from '@angular/common';
import { Component} from '@angular/core';
import { ReviewcardComponent } from '../reviewcard/reviewcard.component';

@Component({
  selector: 'app-reviewdetails',
  standalone: true,
  imports: [CommonModule, ReviewcardComponent],
  templateUrl: './reviewdetails.component.html',
  styleUrl: './reviewdetails.component.scss'
})
export class ReviewdetailsComponent {

}
