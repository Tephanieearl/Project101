import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-sub-navigation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sub-navigation.component.html',
  styleUrl: './sub-navigation.component.scss'
})
export class SubNavigationComponent {
  @Input() tabs: string[] = [];
  activeTab: number = 0;

  changeTab(index: number) {
    this.activeTab = index;
  }


  toggleSearch(): void {
    const searchInput = document.getElementById('search-navbar');
    if (searchInput){
      searchInput.classList.toggle('hidden');
    }
  }
}
