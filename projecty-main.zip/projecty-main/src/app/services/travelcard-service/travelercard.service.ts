import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TravelercardService {

  travelerCardsData = [
    {
      locationName: 'Nusugbu, Batangas',
      destinationName: 'Fortune Island',
      categories: ['Adventure', 'Sea'],
      imageUrl: 'https://images.unsplash.com/photo-1505370632420-d1e987d5c75c',
      authorName: 'Ivan Torres',
      avatar: 'https://images.unsplash.com/profile-1598022349778-ee6869101631image',
      likesCount: 22,
      commentsCount: 20,
    },
    {
      locationName: 'Las Casas, Bagac',
      destinationName: 'One Horsepower',
      categories: ['Adventure', 'History', 'Art&Architecture'],
      imageUrl:
        'https://images.unsplash.com/photo-1553323855-cc1abf1930d2?q=80&w=2071',
        avatar: 'https://images.unsplash.com/profile-1560767804803-40f94676ea44',
        authorName: 'Vernon Cenzon',
        likesCount: 10,
        commentsCount: 5,
      },
      {
        locationName: 'Sabtang, Batanes',
        destinationName: 'Chamantad-Tinyan Viewpoint',
        categories: ['Adventure', 'Food'],
        imageUrl:
        'https://images.unsplash.com/photo-1612108542699-594a7551bc4e?q=80&w=2071',
        avatar: 'https://images.unsplash.com/profile-1603781489527-5eb8d8a8c6f3image?bg=fff&crop=faces&dpr=1&h=150&w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
        authorName: 'John Alvin Merin',
        likesCount: 4,
        commentsCount: 12,
      },
      {
        locationName: 'Tagaytay, Cavite',
        destinationName: 'Bulalo ',
        categories: ['Food'],
        imageUrl: 'https://images.unsplash.com/photo-1583913459026-781129ce061f',
        avatar: 'https://images.unsplash.com/profile-1580424612114-3f5bf819e7bcimage?bg=fff&crop=faces&dpr=1&h=150&w=150',
      authorName: 'Felipe Sacudon',
      likesCount: 10,
      commentsCount: 5,
    },
    {
      locationName: 'Benguet',
      destinationName: 'Now where did I put my coffee?',
      categories: ['Adventure', 'Mountain'],
      imageUrl: 'https://images.unsplash.com/photo-1562307030-2c286048cfd4',
      avatar: 'https://images.unsplash.com/profile-1562558953902-03f594a8ea38?bg=fff&crop=faces&dpr=1&h=150&w=150',
      authorName: 'Marty Garcia',
      likesCount: 10,
      commentsCount: 5,
    },
    {
      locationName: 'Intramuros , Manila',
      destinationName: 'Graffiti in Manila',
      categories: ['Art&Architecture', 'Adventure'],
      imageUrl: 'https://images.unsplash.com/photo-1559566735-f1df6589d059',
      avatar: 'https://images.unsplash.com/profile-fb-1556007007-58abc152cd83.jpg?bg=fff&crop=faces&dpr=1&h=150&w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
      authorName: 'Carmela Asistio',
      likesCount: 10,
      commentsCount: 5,
    },
  ];

  constructor() { }

  getTravelerCardsData() {
    return this.travelerCardsData;
  }

}