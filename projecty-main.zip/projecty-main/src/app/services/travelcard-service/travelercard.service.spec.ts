import { TestBed } from '@angular/core/testing';

import { TravelercardService } from './travelercard.service';

describe('TravelercardService', () => {
  let service: TravelercardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TravelercardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
