import { TestBed } from '@angular/core/testing';

import { RecommendedDataService } from './recommended-data.service';

describe('RecommendedDataService', () => {
  let service: RecommendedDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RecommendedDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
