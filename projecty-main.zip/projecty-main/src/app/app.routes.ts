import { Routes } from '@angular/router';
import { HomeComponent } from './pages/public/home/home.component';
import { RegisterComponent } from './pages/auth/register/register.component';
import { LoginComponent } from './pages/auth/login/login.component';
import { CategoriesComponent } from './pages/public/categories/categories.component';
import { AdventureComponent } from './pages/public/categories/adventure/adventure.component';
import { FoodComponent } from './pages/public/categories/food/food.component';
import { NatureComponent } from './pages/public/categories/nature/nature.component';
import { ArtAndArchitectureComponent } from './pages/public/categories/art-and-architecture/art-and-architecture.component';
import { HistoricalComponent } from './pages/public/categories/historical/historical.component';
import { CityComponent } from './pages/public/categories/city/city.component';
import { FeedComponent } from './pages/public/feed/feed.component';
import { PostDetailsComponent } from './components/user/post-details/post-details.component';
import { BookingDetailsComponent } from './components/book/booking-details/booking-details.component';
import { EventsComponent } from './pages/explore/events/events.component';
import { BecomeALocalGuideComponent } from './pages/public/become-a-local-guide/become-a-local-guide.component';
import { LocalGuideComponent } from './pages/explore/local-guide/local-guide.component';
import { RentalServicesComponent } from './pages/public/categories/rental-services/rental-services.component';
import { TutorialsAndLessonsComponent } from './pages/public/categories/tutorials-and-lessons/tutorials-and-lessons.component';
import { TourAndTravelComponent } from './pages/public/categories/tour-and-travel/tour-and-travel.component';
import { EventPlanningServicesComponent } from './pages/public/categories/event-planning-services/event-planning-services.component';
import { SellerProfileComponent } from './user/seller/seller-profile/seller-profile.component';
import { BuyerProfileComponent } from './user/buyer/buyer-profile/buyer-profile.component';
import { BlogDetailsComponent } from './components/blogs/blog-details/blog-details.component';
import { DiscoverComponent } from './pages/explore/discover/discover.component';
import { HireMeComponent } from './components/book/hire-me/hire-me.component';
import { CebuCityComponent } from './pages/cities/cebu-city/cebu-city.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'sign-up', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'be-a-local-guide', component: BecomeALocalGuideComponent },
  { path: 'categories', component: CategoriesComponent },
  { path: 'categories/adventure', component: AdventureComponent },
  { path: 'categories/food', component: FoodComponent },
  { path: 'categories/nature', component: NatureComponent },
  {
    path: 'categories/art-and-architecture',
    component: ArtAndArchitectureComponent,
  },
  { path: 'categories/historical', component: HistoricalComponent },
  { path: 'categories/city', component: CityComponent },
  { path: 'categories/rental-services', component: RentalServicesComponent },
  { path: 'categories/tutorials-and-lessons', component: TutorialsAndLessonsComponent },  
  { path: 'categories/tour-and-travel', component: TourAndTravelComponent },  
  { path: 'categories/event-planning-and-services', component: EventPlanningServicesComponent },  
  { path: 'feed', component: FeedComponent },
  {path: 'feed/post', component:PostDetailsComponent},
  {path: 'explore/events', component: EventsComponent},
  {path: 'explore/local-guides', component: LocalGuideComponent},
  {path: 'explore/local-guides/blog-detail', component: BlogDetailsComponent},
  {path: 'explore/discover', component: DiscoverComponent},
  { path: 'booking-details', component: BookingDetailsComponent }, 
  { path: 'booking-details/hire-me', component: HireMeComponent }, 
  { path: 'seller-profile', component: SellerProfileComponent }, 
  { path: 'buyer-profile', component: BuyerProfileComponent }, 
  { path: 'city/cebu-city', component: CebuCityComponent }, 
];
