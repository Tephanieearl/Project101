import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { BookingcardComponent } from '../../../components/bookingcard/bookingcard.component';
import { RecommendedCarouselComponent } from '../../../components/recommended-carousel/recommended-carousel.component';

@Component({
  selector: 'app-buyer-profile',
  standalone: true,
  imports: [CommonModule, BookingcardComponent, RecommendedCarouselComponent],
  templateUrl: './buyer-profile.component.html',
  styleUrl: './buyer-profile.component.scss'
})
export class BuyerProfileComponent {
  recommendForYou: any[] = [
    {
      title: 'Camera Rental',
      rating: '4.8',
      description:
        'Rent professional-grade cameras for your photography or videography projects.',
      image:
        '/assets/popular-services/camera.jpg',
      price: '$500',
    },
    {
      title: 'Car Rental',
      rating: '4',
      description:
        'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
      image:
        '/assets/popular-services/car.jpg',
      price: '$600',
    },
    {
      title: 'Photography',
      rating: '4',
      description:
        'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
      image:
        '/assets/popular-services/photography.jpg',
      price: '$600',
    },
  ];
}
