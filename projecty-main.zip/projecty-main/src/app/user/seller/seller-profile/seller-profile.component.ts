import { Component } from '@angular/core';
import { BookingcardComponent } from '../../../components/bookingcard/bookingcard.component';
import { CommonModule } from '@angular/common';
import { RecommendedCarouselComponent } from '../../../components/recommended-carousel/recommended-carousel.component';

@Component({
  selector: 'app-seller-profile',
  standalone: true,
  imports: [BookingcardComponent, CommonModule, RecommendedCarouselComponent],
  templateUrl: './seller-profile.component.html',
  styleUrl: './seller-profile.component.scss'
})
export class SellerProfileComponent {
    // popularCardsData = [
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1542213493895-edf5b94f5a96',
  //     city: 'Boracay',
  //     description:
  //       'known for its pristine white sandy beaches and lively nightlife',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1609860332558-d3b65ed04d89',
  //     city: 'Palawan',
  //     description:
  //       'famous for its stunning landscapes, including the Puerto Princesa Subterranean River National Park',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1587355052582-b3107140afd4',
  //     city: 'Cebu',
  //     description:
  //       'offers beautiful beaches, historical sites like Magellan\'s Cross, and vibrant markets',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1519010470956-6d877008eaa4',
  //     city: 'Manila',
  //     description:
  //       'the capital city, featuring cultural landmarks such as Intramuros and Rizal Park',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1591506557489-e8ca407063e7',
  //     city: 'Bohol',
  //     description:
  //       'home to the Chocolate Hills and unique tarsier sanctuary',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1627268770654-654e98b0a72b',
  //     city: 'Baguio',
  //     description:
  //       'a popular hill station known for its cool climate, scenic views, and cultural sites',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1587659584959-fb5849fb6d26',
  //     city: 'Vigan',
  //     description:
  //       'famous for its well-preserved Spanish colonial architecture',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1565340076861-7a6667b36072',

  //     city: 'Siargao',
  //     description:
  //       'a paradise for surfers with its excellent waves and idyllic beaches',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1598935821198-3f4a54b116fb',
  //     city: 'Batanes',
  //     description:
  //       'known for its rugged landscapes, traditional Ivatan villages, and ancient stone houses',
  //   },
    
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1590077522856-219f9032a2f2',
  //     city: 'Davao',
  //     description:
  //       'offers diverse attractions including Mount Apo, Philippine Eagle Center, and vibrant markets',
  //   },
    
  // ];
  popularServicesCraouselData: any[] = [
    {
      title: 'Camera Rental',
      rating: '4.8',
      description:
        'Rent professional-grade cameras for your photography or videography projects.',
      image:
        '/assets/popular-services/camera.jpg',
      price: '$500',
    },
    {
      title: 'Car Rental',
      rating: '4',
      description:
        'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
      image:
        '/assets/popular-services/car.jpg',
      price: '$600',
    },
    {
      title: 'Photography',
      rating: '4',
      description:
        'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
      image:
        '/assets/popular-services/photography.jpg',
      price: '$600',
    },
  ];

}
