import { Component } from '@angular/core';
import { SubNavigationComponent } from '../../../layouts/public/sub-navigation/sub-navigation.component';

@Component({
  selector: 'app-local-guide',
  standalone: true,
  imports: [SubNavigationComponent],
  templateUrl: './local-guide.component.html',
  styleUrl: './local-guide.component.scss'
})
export class LocalGuideComponent {
  subNavigationTabs: string[] = ['All', 'Tips and Tricks', 'Tab 3', 'Tab 4'];
}
