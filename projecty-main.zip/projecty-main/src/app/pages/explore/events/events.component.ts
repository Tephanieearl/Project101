import { Component } from '@angular/core';
import { BookingcardComponent } from '../../../components/bookingcard/bookingcard.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-events',
  standalone: true,
  imports: [BookingcardComponent, CommonModule],
  templateUrl: './events.component.html',
  styleUrl: './events.component.scss'
})
export class EventsComponent {

  adventureDataArray: any[] = [
    {
      title: 'I will ',
      rating: '5',
      description:
        'Discover the breathtaking beauty of the highest peak in Luzon. Trek through misty trails to witness stunning sunrise views above the sea of clouds.',
      image:
        'https://images.unsplash.com/photo-1633670425294-cbf6ce988408',
      price: '$500',
    },
    {
      title: 'Siargao Surfing',
      rating: '4',
      description:
        'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
      image:
        'https://images.unsplash.com/photo-1565565915331-293fd8113954',
      price: '$600',
    },
    // Add more adventures here...
  ];
}
