import { Component, OnInit ,Output, EventEmitter } from '@angular/core';
import { CarouselComponent } from '../../../components/carousel/carousel.component';
import { PopularcardComponent } from '../../../components/popularcard/popularcard.component';
import { TravelercardComponent } from '../../../components/travelercard/travelercard.component';
import { PaginationComponent } from '../../../components/pagination/pagination.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { TravelercardService } from '../../../services/travelcard-service/travelercard.service';
import { RecommendedCarouselComponent } from '../../../components/recommended-carousel/recommended-carousel.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    CarouselComponent,
    PopularcardComponent,
    TravelercardComponent,
    PaginationComponent,
    TravelercardComponent,
    RouterModule,
    RecommendedCarouselComponent
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent implements OnInit {
  categoryCarouselData = [
    {
      imageUrl: '/assets/categories/rent.jpg',
      desc: 'Equipment, Vehicle, Property',
      title: 'Rental Services',
      url: 'categories/rental-services',
    },
    {
      imageUrl: '/assets/categories/tutorials.jpg',
      desc: 'Cooking, Arts, Music',
      title: 'Tutorials and Lessons',
      url: 'categories/tutorials-and-lessons',
    },
    {
      imageUrl: '/assets/categories/event_plan.jpg',
      desc: 'Planning, Photography',
      title: 'Event Services',
      url: 'categories/event-planning-and-services',
    },

    {
      imageUrl: '/assets/categories/tours.jpg',
      desc: 'Local Guides, Adventure, Cultural',
      title: 'Tour and Travel Services',
      url: 'categories/tour-and-travel',
    },
  ];
  // popularCardsData = [
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1542213493895-edf5b94f5a96',
  //     city: 'Boracay',
  //     description:
  //       'known for its pristine white sandy beaches and lively nightlife',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1609860332558-d3b65ed04d89',
  //     city: 'Palawan',
  //     description:
  //       'famous for its stunning landscapes, including the Puerto Princesa Subterranean River National Park',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1587355052582-b3107140afd4',
  //     city: 'Cebu',
  //     description:
  //       'offers beautiful beaches, historical sites like Magellan\'s Cross, and vibrant markets',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1519010470956-6d877008eaa4',
  //     city: 'Manila',
  //     description:
  //       'the capital city, featuring cultural landmarks such as Intramuros and Rizal Park',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1591506557489-e8ca407063e7',
  //     city: 'Bohol',
  //     description:
  //       'home to the Chocolate Hills and unique tarsier sanctuary',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1627268770654-654e98b0a72b',
  //     city: 'Baguio',
  //     description:
  //       'a popular hill station known for its cool climate, scenic views, and cultural sites',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1587659584959-fb5849fb6d26',
  //     city: 'Vigan',
  //     description:
  //       'famous for its well-preserved Spanish colonial architecture',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1565340076861-7a6667b36072',

  //     city: 'Siargao',
  //     description:
  //       'a paradise for surfers with its excellent waves and idyllic beaches',
  //   },
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1598935821198-3f4a54b116fb',
  //     city: 'Batanes',
  //     description:
  //       'known for its rugged landscapes, traditional Ivatan villages, and ancient stone houses',
  //   },
    
  //   {
  //     imageUrl:
  //       'https://images.unsplash.com/photo-1590077522856-219f9032a2f2',
  //     city: 'Davao',
  //     description:
  //       'offers diverse attractions including Mount Apo, Philippine Eagle Center, and vibrant markets',
  //   },
    
  // ];
  recommendedCraouselData: any[] = [
    {
      title: 'Mount Pulag',
      rating: '5',
      description:
        'Discover the breathtaking beauty of the highest peak in Luzon. Trek through misty trails to witness stunning sunrise views above the sea of clouds.',
      image:
        'https://images.unsplash.com/photo-1633670425294-cbf6ce988408',
      price: '$500',
    },
    {
      title: 'Siargao Surfing',
      rating: '4',
      description:
        'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
      image:
        'https://images.unsplash.com/photo-1565565915331-293fd8113954',
      price: '$600',
    },
    // Add more adventures here...
  ];

  popularServicesCraouselData: any[] = [
    {
      title: 'Camera Rental',
      rating: '4.8',
      description:
        'Rent professional-grade cameras for your photography or videography projects.',
      image:
        '/assets/popular-services/camera.jpg',
      price: '$500',
    },
    {
      title: 'Car Rental',
      rating: '4',
      description:
        'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
      image:
        '/assets/popular-services/car.jpg',
      price: '$600',
    },
    {
      title: 'Photography',
      rating: '4',
      description:
        'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
      image:
        '/assets/popular-services/photography.jpg',
      price: '$600',
    },
  ];

  //Traveler Card Service
  travelerCardsData: {
    locationName: string;
    destinationName: string;
    categories: string[];
    imageUrl: string;
    authorName: string;
    avatar: string;
    likesCount: number;
    commentsCount: number;
  }[] = [];

  constructor(private TravelercardService: TravelercardService) { }

  ngOnInit(): void {
    // Retrieve traveler cards data
    this.travelerCardsData = this.TravelercardService.getTravelerCardsData();

    // Set up other initialization logic
    this.checkSeeMoreButton();
  }
  
  // Travelers Card Properties
  showMaxCards = 6;
  showSeeMoreButton = false;

  checkSeeMoreButton() {
    this.showSeeMoreButton = this.travelerCardsData.length > this.showMaxCards;
  }

// Pagination properties
// currentPage = 1;
// pageSize = 6;

// get totalPages(): number {
//   return Math.ceil(this.popularCardsData.length / this.pageSize);
// }

// get paginatedData(): any[] {
//   const startIndex = (this.currentPage - 1) * this.pageSize;
//   const endIndex = startIndex + this.pageSize;
//   return this.popularCardsData.slice(startIndex, endIndex);
// }

// onPageChange(pageNumber: number): void {
//   // Assign the page number to currentPage
//   this.currentPage = pageNumber;
// }
}