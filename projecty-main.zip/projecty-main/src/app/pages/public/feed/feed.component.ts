import { Component, OnInit } from '@angular/core';
import { TravelercardComponent } from '../../../components/travelercard/travelercard.component';
import { CommonModule } from '@angular/common';
import { TravelercardService } from '../../../services/travelcard-service/travelercard.service';

@Component({
  selector: 'app-feed',
  standalone: true,
  imports: [TravelercardComponent, CommonModule],
  templateUrl: './feed.component.html',
  styleUrl: './feed.component.scss',
})
export class FeedComponent implements OnInit {
  travelerCardsData: {
    locationName: string;
    destinationName: string;
    categories: string[];
    imageUrl: string;
    authorName: string;
    avatar: string;
    likesCount: number;
    commentsCount: number;
  }[] = [];

  constructor(private TravelercardService: TravelercardService) { }

  ngOnInit(): void {
    this.travelerCardsData = this.TravelercardService.getTravelerCardsData();
  }
}