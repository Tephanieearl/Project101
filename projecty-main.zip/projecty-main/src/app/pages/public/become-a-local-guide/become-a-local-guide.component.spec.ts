import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BecomeALocalGuideComponent } from './become-a-local-guide.component';

describe('BecomeALocalGuideComponent', () => {
  let component: BecomeALocalGuideComponent;
  let fixture: ComponentFixture<BecomeALocalGuideComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BecomeALocalGuideComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BecomeALocalGuideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
