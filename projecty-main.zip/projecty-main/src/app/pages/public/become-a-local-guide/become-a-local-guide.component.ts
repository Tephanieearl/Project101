import { Component } from '@angular/core';
import { FaqsComponent } from '../../../components/faqs/faqs.component';

@Component({
  selector: 'app-become-a-local-guide',
  standalone: true,
  imports: [FaqsComponent],
  templateUrl: './become-a-local-guide.component.html',
  styleUrl: './become-a-local-guide.component.scss'
})
export class BecomeALocalGuideComponent {

}
