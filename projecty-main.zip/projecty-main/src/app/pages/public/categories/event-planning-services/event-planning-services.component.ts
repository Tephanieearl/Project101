import { Component } from '@angular/core';
import { BookingcardComponent } from '../../../../components/bookingcard/bookingcard.component';
import { PaginationComponent } from '../../../../components/pagination/pagination.component';
import { SubNavigationComponent } from '../../../../layouts/public/sub-navigation/sub-navigation.component';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-event-planning-services',
  standalone: true,
  imports: [BookingcardComponent, PaginationComponent, SubNavigationComponent, CommonModule, RouterLink],
  templateUrl: './event-planning-services.component.html',
  styleUrl: './event-planning-services.component.scss'
})
export class EventPlanningServicesComponent {
  subNavigationTabs: string[] = ['All', 'Tips and Tricks', 'Tab 3', 'Tab 4'];

  eventPlanningDataArray: any[] = [
    {
      title: 'Wedding Planning Package',
      rating: '4.8',
      description: 'Let us bring your dream wedding to life with our comprehensive planning package. From venue selection to floral arrangements and catering, we\'ll take care of every detail.',
      image: '/assets/categories/event-planning-and-services/wedding-planning.jpg',
      price: '₱50,000'
    },
    {
      title: 'Birthday Party Planning',
      rating: '4.7',
      description: 'Celebrate your special day in style with our birthday party planning services. From themed decorations to entertainment and cake, we\'ll create an unforgettable experience.',
      image: '/assets/categories/event-planning-and-services/birthday-party-planning.jpg',
      price: '₱20,000'
    },
    {
      title: 'Concert Production',
      rating: '4.9',
      description: 'Bring your concert vision to life with our production package. From stage design and lighting to sound engineering and artist management, we\'ll ensure a memorable event.',
      image: '/assets/categories/event-planning-and-services/concert-production.jpg',
      price: '₱150,000'
    },
    {
      title: 'Festival Organization',
      rating: '4.6',
      description: 'Organize a successful festival with our expert services. We\'ll handle permits, vendor coordination, security, and marketing to ensure a safe and enjoyable experience for attendees.',
      image: '/assets/categories/event-planning-and-services/festival-organization.jpg',
      price: '₱200,000'
    },
    {
      title: 'Christmas Party Planning',
      rating: '4.5',
      description: 'Plan unforgettable Christmas parties with our expert organization services. We handle venue decoration, catering, and entertainment arrangements.',
      image: '/assets/categories/event-planning-and-services/christmas-party-planning.jpg',
      price: '₱35,000'
    },
    {
      title: 'Anniversary Coordinator',
      rating: '4.5',
      description: 'Celebrate milestones with our anniversary celebration coordination services. We handle venue decoration, catering, and entertainment arrangements.',
      image: '/assets/categories/event-planning-and-services/anniversary-coordinator.jpg',
      price: '₱40,000'
    },
    {
      title: 'Conventions Management',
      rating: '4.6',
      description: 'Manage successful conferences and conventions with our expert services. We handle venue booking, speaker coordination, and delegate registration.',
      image: '/assets/categories/event-planning-and-services/convention.jpg',
      price: '₱85,000'
    },
  ];

  // Pagination properties
  currentPage = 1;
  pageSize = 12;

  get totalPages(): number {
    return Math.ceil(this.eventPlanningDataArray.length / this.pageSize);
  }

  get paginatedData(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    return this.eventPlanningDataArray.slice(startIndex, endIndex);
  }

  onPageChange(pageNumber: number): void {
    // Assign the page number to currentPage
    this.currentPage = pageNumber;
  }
}
