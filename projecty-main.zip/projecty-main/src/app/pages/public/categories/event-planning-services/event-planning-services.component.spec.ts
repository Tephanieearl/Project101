import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventPlanningServicesComponent } from './event-planning-services.component';

describe('EventPlanningServicesComponent', () => {
  let component: EventPlanningServicesComponent;
  let fixture: ComponentFixture<EventPlanningServicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EventPlanningServicesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EventPlanningServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
