import { Component } from '@angular/core';
import { BookingcardComponent } from '../../../components/bookingcard/bookingcard.component';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-categories',
  standalone: true,
  imports: [BookingcardComponent, RouterLink],
  templateUrl: './categories.component.html',
  styleUrl: './categories.component.scss'
})
export class CategoriesComponent {

}
