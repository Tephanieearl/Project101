import { Component, Input, EventEmitter, Output } from '@angular/core';
import { BookingcardComponent } from '../../../../components/bookingcard/bookingcard.component';
import { CommonModule } from '@angular/common';
import { PaginationComponent } from '../../../../components/pagination/pagination.component';

@Component({
  selector: 'app-adventure',
  standalone: true,
  imports: [BookingcardComponent, CommonModule, PaginationComponent],
  templateUrl: './adventure.component.html',
  styleUrl: './adventure.component.scss',
})
export class AdventureComponent {
  adventureDataArray: any[] = [
    {
      title: 'Mount Pulag',
      rating: '5',
      description:
        'Discover the breathtaking beauty of the highest peak in Luzon. Trek through misty trails to witness stunning sunrise views above the sea of clouds.',
      image:
        'https://images.unsplash.com/photo-1633670425294-cbf6ce988408',
      price: '$500',
    },
    {
      title: 'Siargao Surfing',
      rating: '4',
      description:
        'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
      image:
        'https://images.unsplash.com/photo-1565565915331-293fd8113954',
      price: '$600',
    },
    {
      title: 'Banaue Rice Terraces Tour',
      rating: '4',
      description:
        'Explore the stunning Banaue Rice Terraces, a UNESCO World Heritage site. Immerse yourself in the rich culture and heritage of the Ifugao people.',
      image:
        'https://images.unsplash.com/photo-1621217308295-afe2f0b40a69',
      price: '$400',
    },
    // Add more adventures here...
    {
      title: 'Taal Volcano',
      rating: '4',
      description:
        "Embark on an adventure to Taal Volcano, one of the Philippines' most iconic natural landmarks. Hike to the crater rim and marvel at the breathtaking views of the volcanic landscape.",
      image:
        'https://images.unsplash.com/photo-1621420561012-1adfa8e6bc2e',
      price: '$350',
    },
    {
      title: 'Coron Island Expedition',
      rating: '4',
      description:
        'Discover the pristine beauty of Coron Island in Palawan. Embark on a thrilling expedition to secret lagoons, hidden beaches, and majestic limestone cliffs.',
      image:
        'https://images.unsplash.com/photo-1646826484606-1e75e0d7d2ba',
      price: '$700',
    },
    {
      title: 'Cebu Adventure',
      rating: '4',
      description:
        'Experience the adrenaline rush of canyoneering in the rugged landscapes of Cebu. Dive, swim, and rappel through natural rock formations and cascading waterfalls.',
      image:
        'https://images.unsplash.com/photo-1576647025587-2b77cd953cba',
      price: '$450',
    },
    {
      title: 'Palawan Island Hopping',
      rating: '4',
      description:
        'Hop on a boat and explore the enchanting islands of Palawan. Discover hidden coves, vibrant coral reefs, and pristine white sand beaches.',
      image:
        'https://images.unsplash.com/photo-1694854395365-91e72b309e5d',
      price: '$550',
    },
    {
      title: 'Boracay Parasailing Experience',
      rating: '4',
      description:
        'Soar above the azure waters of Boracay on an exhilarating parasailing adventure. Enjoy panoramic views of the island and feel the thrill of flying high above the sea.',
      image:
        'https://images.unsplash.com/photo-1495031451303-d8ab59c8df37',
      price: '$250',
    },
    {
      title: 'Camiguin Island ',
      rating: '4',
      description:
        'Discover hidden waterfalls, hot springs, and ancient ruins along the way.',
      image:
        'https://images.unsplash.com/photo-1551521021-d929e606badc',
      price: '$400',
    },
    {
      title: 'Batanes Bike Tour',
      rating: '4',
      description:
        'Explore the scenic landscapes of Batanes on a thrilling bike tour. Pedal through rolling hills, rugged coastlines, and picturesque villages.',
      image:
        'https://images.unsplash.com/photo-1612108541589-d76c98b2de97',
      price: '$300',
    },
    {
      title: 'Siquijor Island Hopping',
      rating: '4',
      description:
        'Hop on a boat and explore the mystical islands of Siquijor. Discover secluded beaches, natural pools, and enchanting waterfalls.',
      image:
        'https://images.unsplash.com/photo-1685685476548-8d57bc46032d',
      price: '$350',
    },
    {
      title: 'Bohol Chocolate Hills Tour',
      rating: '4',
      description:
        'Visit the iconic Chocolate Hills of Bohol and marvel at their unique geological formations. Explore lush greenery, wildlife sanctuaries, and historic landmarks.',
      image:
        'https://images.unsplash.com/photo-1667823506151-836beb11723d',
      price: '$250',
    },
    {
      title: 'Dumaguete Dolphin Watching',
      rating: '4',
      description:
        'Embark on an exciting dolphin watching adventure off the coast of Dumaguete. Get up close and personal with playful dolphins in their natural habitat.',
      image:
        'https://lh3.googleusercontent.com/p/AF1QipOYtHUarj2ni0mGZLfAJatt8bzYr3_s9eui9v_9=s1360-w1360-h1020',
      price: '$200',
    },
    {
      title: 'Anilao Diving Expedition',
      rating: '4',
      description:
        'Dive into the crystal-clear waters of Anilao and discover a vibrant underwater world. Explore colorful coral reefs, diverse marine life, and spectacular dive sites.',
      image:
        'https://i0.wp.com/www.traveling-up.com/wp-content/uploads/2018/02/fwd-scuba-diving-bucketlist-anilao-batangas-underwater-travelup-2.jpg',
      price: '$400',
    },
    // Add more adventures here...
  ];

  
  // Pagination properties
  currentPage = 1;
  pageSize = 12;

  get totalPages(): number {
    return Math.ceil(this.adventureDataArray.length / this.pageSize);
  }

  get paginatedData(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    return this.adventureDataArray.slice(startIndex, endIndex);
  }

  onPageChange(pageNumber: number): void {
    // Assign the page number to currentPage
    this.currentPage = pageNumber;
  }
}
