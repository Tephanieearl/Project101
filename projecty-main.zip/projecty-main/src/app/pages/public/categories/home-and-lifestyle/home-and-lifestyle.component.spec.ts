import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeAndLifestyleComponent } from './home-and-lifestyle.component';

describe('HomeAndLifestyleComponent', () => {
  let component: HomeAndLifestyleComponent;
  let fixture: ComponentFixture<HomeAndLifestyleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HomeAndLifestyleComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HomeAndLifestyleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
