import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { SubNavigationComponent } from '../../../../layouts/public/sub-navigation/sub-navigation.component';
import { PaginationComponent } from '../../../../components/pagination/pagination.component';
import { BookingcardComponent } from '../../../../components/bookingcard/bookingcard.component';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-tutorials-and-lessons',
  standalone: true,
  imports: [CommonModule, SubNavigationComponent, PaginationComponent, BookingcardComponent, RouterModule],
  templateUrl: './tutorials-and-lessons.component.html',
  styleUrl: './tutorials-and-lessons.component.scss'
})
export class TutorialsAndLessonsComponent {
  subNavigationTabs: string[] = ['All', 'Tips and Tricks', 'Tab 3', 'Tab 4'];

  tutorialsDataArray: any[] = [
    {
      title: 'Web Development',
      rating: '4.7',
      description: 'Join our intensive bootcamp and learn the ins and outs of web development, from HTML and CSS to JavaScript and beyond.',
      image: '/assets/categories/tutorials-and-lessons/web-development-bootcamp.jpg',
      price: '₱5,000'
    },
    {
      title: 'Photoshop Mastery',
      rating: '4.6',
      description: 'Unlock the full potential of Adobe Photoshop with our comprehensive mastery course, covering advanced techniques for photo editing and graphic design.',
      image: '/assets/categories/tutorials-and-lessons/photoshop-mastery.jpg',
      price: '₱3,500'
    },
    {
      title: 'Cooking Workshop',
      rating: '4.8',
      description: 'Elevate your culinary skills with our gourmet cooking workshop, where you\'ll learn to prepare exquisite dishes from around the world.',
      image: '/assets/categories/tutorials-and-lessons/cooking-workshop.jpg',
      price: '₱4,000'
    },
    {
      title: 'Portrait Photography',
      rating: '4.5',
      description: 'Take your portrait photography to the next level with our masterclass, focusing on lighting techniques, posing, and composition for stunning portraits.',
      image: '/assets/categories/tutorials-and-lessons/portrait-photography.jpg',
      price: '₱3,000'
    },
    {
      title: 'Mobile App Development Crash Course',
      rating: '4.9',
      description: 'Learn to build mobile apps from scratch with our crash course, covering iOS and Android development using popular frameworks like React Native and Flutter.',
      image: '/assets/categories/tutorials-and-lessons/mobile-app-dev.jpg',
      price: '₱2,500'
    },
    {
      title: 'Fashion Design Workshop',
      rating: '4.7',
      description: 'Discover the art of fashion design in our hands-on workshop, where you\'ll learn sketching, pattern making, and garment construction techniques.',
      image: '/assets/categories/tutorials-and-lessons/fashion-design.jpg',
      price: '₱1,800'
    },
    {
      title: 'Digital Marketing',
      rating: '4.6',
      description: 'Earn your digital marketing certification with our comprehensive program, covering SEO, social media marketing, email marketing, and more.',
      image: '/assets/categories/tutorials-and-lessons/digital-marketing.jpg',
      price: '₱3,000'
    },
    {
      title: 'Yoga and Meditation',
      rating: '4.8',
      description: 'Embark on a journey of self-discovery with our yoga and meditation retreat, designed to rejuvenate your mind, body, and soul.',
      image: '/assets/categories/tutorials-and-lessons/yoga-and-meditation.jpg',
      price: '₱3,500'
    },
    {
      title: 'Music Production',
      rating: '4.5',
      description: 'Learn the art of music production from industry experts, covering everything from songwriting and arrangement to recording and mixing.',
      image: '/assets/categories/tutorials-and-lessons/music-production.jpg',
      price: '₱4,500'
    },
    {
      title: 'Creative Writing Workshop',
      rating: '4.7',
      description: 'Unleash your creativity with our creative writing workshop, where you\'ll explore various forms of writing and develop your own unique voice.',
      image: '/assets/categories/tutorials-and-lessons/creative-writing.jpg',
      price: '₱2,500'
    },
    {
      title: 'Fitness Training Program',
      rating: '4.6',
      description: 'Achieve your fitness goals with our personalized training program, tailored to your needs and preferences by certified fitness instructors.',
      image: '/assets/categories/tutorials-and-lessons/fitness-training.jpg',
      price: '₱4,500'
    },
    {
      title: 'Artificial Intelligence',
      rating: '4.8',
      description: 'Dive into the world of artificial intelligence with our in-depth course, covering machine learning, neural networks, and AI applications.',
      image: '/assets/categories/tutorials-and-lessons/artificial-intelligence.jpg',
      price: '₱3,100'
    },
    {
      title: 'Personal Finance Workshop',
      rating: '4.7',
      description: 'Take control of your finances with our personal finance workshop, where you\'ll learn budgeting, investing, and wealth-building strategies.',
      image: '/assets/categories/tutorials-and-lessons/personal-finance.jpg',
      price: '₱2,500'
    },
    {
      title: 'Parenting Seminar Series',
      rating: '4.8',
      description: 'Gain valuable insights and practical tips on parenting in our seminar series, covering topics like child development, discipline, and communication.',
      image: '/assets/categories/tutorials-and-lessons/parenting-seminar.jpg',
      price: '₱2,000'
    }
  ];
  
  // Pagination properties
  currentPage = 1;
  pageSize = 12;

  get totalPages(): number {
    return Math.ceil(this.tutorialsDataArray.length / this.pageSize);
  }

  get paginatedData(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    return this.tutorialsDataArray.slice(startIndex, endIndex);
  }

  onPageChange(pageNumber: number): void {
    // Assign the page number to currentPage
    this.currentPage = pageNumber;
  }

}