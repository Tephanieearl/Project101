import { Component } from '@angular/core';
import { BookingcardComponent } from '../../../../components/bookingcard/bookingcard.component';
import { CommonModule } from '@angular/common';
import { PaginationComponent } from '../../../../components/pagination/pagination.component';
import { SubNavigationComponent } from '../../../../layouts/public/sub-navigation/sub-navigation.component';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-rental-services',
  standalone: true,
  imports: [BookingcardComponent, CommonModule, PaginationComponent, SubNavigationComponent, RouterModule],
  templateUrl: './rental-services.component.html',
  styleUrl: './rental-services.component.scss'
})
export class RentalServicesComponent {

  subNavigationTabs: string[] = ['All', 'Tips and Tricks', 'Tab 3', 'Tab 4'];

  rentDataArray: any[] = [
    {
      title: 'Mountain Bikes',
      rating: '4.5',
      description:
        'Explore rugged terrains effortlessly with our reliable mountain bikes.',
      image:
        '/assets/categories/rental-services/mountain-bikes.jpg',
      price: '₱3,200',
    },
    {
      title: 'Electric Scooters',
      rating: '4.8',
      description:
        'Zip through city streets with ease on our eco-friendly electric scooters.',
      image:
        '/assets/categories/rental-services/electric-scooter.jpg',
      price: '₱2,400',
    },
    {
      title: 'Drone Rentals',
      rating: '4.9',
      description:
        'Capture breathtaking aerial shots and explore new perspectives with ease. Perfect for filmmakers, photographers, and enthusiasts alike.',
      image:
        '/assets/categories/rental-services/drones.jpg',
      price: '₱5,300',
    },
    {
      title: 'Tents',
      rating: '4.5',
      description:"Create memorable outdoor events with our spacious and weather-resistant tents.",
      image:
        '/assets/categories/rental-services/tents.jpg',
      price: '₱500',
    },
    {
      title: 'Sound Systems',
      rating: '4.6',
      description:
        'Keep the party alive with our high-quality sound systems and speakers.',
      image:
        '/assets/categories/rental-services/sound-systems.jpg',
      price: '₱1,100',
    },
    {
      title: 'Costume Rentals',
      rating: '4.6',
      description: 'Transform into your favorite character with our wide selection of costumes for rent.',
      image: '/assets/categories/rental-services/costumes.jpg',
      price: '₱800'
    },
    {
      title: 'Cameras',
      rating: '4.7',
      description: 'Capture life\'s moments with stunning clarity using our professional-grade cameras.',
      image: '/assets/categories/rental-services/camera.jpg',
      price: '₱800'
    },
    {
      title: 'Textbook Rentals',
      rating: '4.6',
      description: 'Access essential textbooks for your studies affordably with our textbook rental service.',
      image: '/assets/categories/rental-services/textbooks.jpg',
      price: '₱400'
    },
    {
      title: 'Laptop',
      rating: '4.7',
      description: 'Stay productive on the go with our reliable laptops available for rent.',
      image: '/assets/categories/rental-services/laptop.jpg',
      price: '₱6,000'
    },
    {
      title: 'Camping Gear',
      rating: '4.8',
      description: 'Embark on outdoor adventures with our high-quality camping gear available for rent.',
      image: '/assets/categories/rental-services/camping.jpg',
      price: '₱3,200'
    },
    {
      title: 'Motorcycles',
      rating: '4.8',
      description: 'Experience freedom on the open road with our selection of motorcycles available for rent.',
      image: '/assets/categories/rental-services/motorcycles.jpg',
      price: '₱5,500'
    },
    {
      title: 'Keyboard',
      rating: '4.7',
      description: 'Explore the world of music with our versatile keyboard, perfect for beginners and professionals alike.',
      image: '/assets/categories/rental-services/keyboard.jpg',
      price: '₱1,200'
    },
    {
      title: 'Guitar',
      rating: '4.6',
      description: 'Strum away and create beautiful melodies with our classic acoustic guitar.',
      image: '/assets/categories/rental-services/guitar.jpg',
      price: '₱500'
    },
    {
      title: 'Drum Set',
      rating: '4.8',
      description: 'Feel the rhythm and unleash your inner drummer with our high-quality drum set.',
      image: '/assets/categories/rental-services/drum-set.jpg',
      price: '₱300 per day'
    },
  ];

  // Pagination properties
  currentPage = 1;
  pageSize = 12;

  get totalPages(): number {
    return Math.ceil(this.rentDataArray.length / this.pageSize);
  }

  get paginatedData(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    return this.rentDataArray.slice(startIndex, endIndex);
  }

  onPageChange(pageNumber: number): void {
    // Assign the page number to currentPage
    this.currentPage = pageNumber;
  }
}