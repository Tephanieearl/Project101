import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RentalServicesComponent } from './rental-services.component';

describe('RentalServicesComponent', () => {
  let component: RentalServicesComponent;
  let fixture: ComponentFixture<RentalServicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RentalServicesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RentalServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
