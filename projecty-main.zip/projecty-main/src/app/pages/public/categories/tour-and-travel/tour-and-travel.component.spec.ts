import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TourAndTravelComponent } from './tour-and-travel.component';

describe('TourAndTravelComponent', () => {
  let component: TourAndTravelComponent;
  let fixture: ComponentFixture<TourAndTravelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TourAndTravelComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TourAndTravelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
