import { Component } from '@angular/core';
import { BookingcardComponent } from '../../../../components/bookingcard/bookingcard.component';
import { RouterLink } from '@angular/router';
import { PaginationComponent } from '../../../../components/pagination/pagination.component';
import { SubNavigationComponent } from '../../../../layouts/public/sub-navigation/sub-navigation.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tour-and-travel',
  standalone: true,
  imports: [BookingcardComponent, RouterLink, PaginationComponent, SubNavigationComponent, CommonModule],
  templateUrl: './tour-and-travel.component.html',
  styleUrl: './tour-and-travel.component.scss'
})
export class TourAndTravelComponent {
  subNavigationTabs: string[] = ['All', 'Tips and Tricks', 'Tab 3', 'Tab 4'];

  tourDataArray: any[] = [
    {
      title: 'Boracay Beach Getaway',
      rating: '4.8',
      description: 'Experience paradise on earth with our Boracay beach getaway package. Enjoy pristine white sand beaches, crystal clear waters, and vibrant nightlife.',
      image: '/assets/categories/tour-and-travel/boracay-beach.jpg',
      price: '₱8,500'
    },
    {
      title: 'Bohol Countryside Tour',
      rating: '4.7',
      description: 'Explore the natural wonders of Bohol with our countryside tour. Visit the Chocolate Hills, see the adorable tarsiers, and cruise along the Loboc River.',
      image: '/assets/categories/tour-and-travel/bohol-countryside.jpg',
      price: '₱5,200'
    },
    {
      title: 'Palawan Island Hopping',
      rating: '4.9',
      description: 'Discover the stunning islands of Palawan with our island hopping tour. Swim in crystal clear lagoons, snorkel among vibrant coral reefs, and relax on pristine beaches.',
      image: '/assets/categories/tour-and-travel/palawan.jpg',
      price: '₱7,200'
    },
    {
      title: 'Banaue Rice Terraces Trek',
      rating: '4.6',
      description: 'Embark on an adventure to the Banaue Rice Terraces, a UNESCO World Heritage Site. Trek through picturesque landscapes and learn about the rich culture of the Ifugao people.',
      image: '/assets/categories/tour-and-travel/banaue-rice-terraces.jpg',
      price: '₱6,800'
    },
    {
      title: 'Siargao Surfing Experience',
      rating: '4.5',
      description: 'Ride the waves in Siargao, the surfing capital of the Philippines. Join our surfing experience and catch the perfect wave in the famous Cloud 9 surf break.',
      image: '/assets/categories/tour-and-travel/siargao-surfing.jpg',
      price: '₱9,000'
    },
    {
      title: 'Coron Island Expedition',
      rating: '4.7',
      description: 'Embark on an expedition to Coron Island and discover its hidden treasures. Explore stunning lagoons, dive into WWII shipwrecks, and hike to breathtaking viewpoints.',
      image: '/assets/categories/tour-and-travel/coron-island.jpg',
      price: '₱7,500'
    },
    {
      title: 'Cebu City Heritage Tour',
      rating: '4.8',
      description: 'Immerse yourself in history and culture with our Cebu City heritage tour. Visit iconic landmarks such as Magellan\'s Cross, Fort San Pedro, and the Basilica Minore del Santo Niño.',
      image: '/assets/categories/tour-and-travel/cebu-city-heritage.jpg',
      price: '₱4,500'
    },
    {
      title: 'Batanes Cultural Immersion',
      rating: '4.9',
      description: 'Experience the unique culture of Batanes with our cultural immersion tour. Explore traditional Ivatan villages, learn about local customs, and savor authentic Ivatan cuisine.',
      image: '/assets/categories/tour-and-travel/batanes-cultural.jpg',
      price: '₱10,000'
    },
    {
      title: 'Davao City Nature Trip',
      rating: '4.6',
      description: 'Discover the natural beauty of Davao City with our nature trip. Visit the Philippine Eagle Center, Eden Nature Park, and Malagos Garden Resort.',
      image: '/assets/categories/tour-and-travel/davao-city-nature.jpg',
      price: '₱6,000'
    },
    {
      title: 'Vigan Heritage Walking',
      rating: '4.7',
      description: 'Step back in time with our Vigan heritage walking tour. Wander through cobblestone streets, admire Spanish colonial architecture, and explore historic landmarks.',
      image: '/assets/categories/tour-and-travel/vigan-heritage.jpg',
      price: '₱3,800'
    },
    {
      title: 'Camiguin Adventure',
      rating: '4.5',
      description: 'Embark on an adrenaline-fueled adventure in Camiguin. Conquer Mount Hibok-Hibok, dive into underwater volcanoes, and relax in natural hot springs.',
      image: '/assets/categories/tour-and-travel/camiguin-adventure.jpg',
      price: '₱8,200'
    },
    {
      title: 'Panglao Island Adventure',
      rating: '4.7',
      description: 'Embark on an adventure to Panglao Island. Dive into vibrant coral gardens, swim with sea turtles, and relax on pristine white sand beaches.',
      image: '/assets/categories/tour-and-travel/panglao-island.jpg',
      price: '₱6,500'
    },
    {
      title: 'Iloilo City Food Tour',
      rating: '4.8',
      description: 'Indulge in a culinary adventure in Iloilo City. Sample delicious local delicacies, explore bustling markets, and savor authentic Ilonggo cuisine.',
      image: '/assets/categories/tour-and-travel/iloilo-city-food.png',
      price: '₱3,500'
    },
    {
      title: 'Mt. Pulag Summit Climb',
      rating: '4.6',
      description: 'Conquer the highest peak in Luzon with our Mt. Pulag summit climb. Experience the breathtaking sunrise above the sea of clouds from the summit.',
      image: '/assets/categories/tour-and-travel/mt-pulag.jpg',
      price: '₱7,800'
    },
  ];

  // Pagination properties
  currentPage = 1;
  pageSize = 12;

  get totalPages(): number {
    return Math.ceil(this.tourDataArray.length / this.pageSize);
  }

  get paginatedData(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    return this.tourDataArray.slice(startIndex, endIndex);
  }

  onPageChange(pageNumber: number): void {
    // Assign the page number to currentPage
    this.currentPage = pageNumber;
  }
}