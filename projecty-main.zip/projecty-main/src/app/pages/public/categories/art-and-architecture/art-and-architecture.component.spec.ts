import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtAndArchitectureComponent } from './art-and-architecture.component';

describe('ArtAndArchitectureComponent', () => {
  let component: ArtAndArchitectureComponent;
  let fixture: ComponentFixture<ArtAndArchitectureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ArtAndArchitectureComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ArtAndArchitectureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
