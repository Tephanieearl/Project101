import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { BookingcardComponent } from '../../../../components/bookingcard/bookingcard.component';
import { PaginationComponent } from '../../../../components/pagination/pagination.component';

@Component({
  selector: 'app-art-and-architecture',
  standalone: true,
  imports: [CommonModule, BookingcardComponent, PaginationComponent],
  templateUrl: './art-and-architecture.component.html',
  styleUrl: './art-and-architecture.component.scss'
})
export class ArtAndArchitectureComponent {

  artAndArchitectureArray: any[] = [
    {
        title: 'Mount Pulag',
        rating: '5',
        description: 'Discover the breathtaking beauty of the highest peak in Luzon. Trek through misty trails to witness stunning sunrise views above the sea of clouds.',
        image: "https://images.unsplash.com/photo-1699890767906-ef5e6feb4582?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        price: '$500'
    },
    {
        title: 'Siargao Surfing',
        rating: '4',
        description: 'Experience world-class surfing in the waves of Siargao. Join fellow surfers from around the globe in this tropical paradise.',
        image: "https://images.unsplash.com/photo-1567002203781-f8238917c3b5?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$600'
    },
    {
        title: 'Banaue Rice Terraces Tour',
        rating: '4',
        description: 'Explore the stunning Banaue Rice Terraces, a UNESCO World Heritage site. Immerse yourself in the rich culture and heritage of the Ifugao people.',
        image: "https://images.unsplash.com/photo-1612046933682-15f0528e7854?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$400'
    },
    // Add more adventures here...
    {
        title: 'Taal Volcano Hiking',
        rating: '4',
        description: 'Embark on an adventure to Taal Volcano, one of the Philippines\' most iconic natural landmarks. Hike to the crater rim and marvel at the breathtaking views of the volcanic landscape.',
        image: "https://images.unsplash.com/photo-1600658330208-f153c773d70f?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$350'
    },
    {
        title: 'Coron Island Expedition',
        rating: '4',
        description: 'Discover the pristine beauty of Coron Island in Palawan. Embark on a thrilling expedition to secret lagoons, hidden beaches, and majestic limestone cliffs.',
        image: "https://images.unsplash.com/photo-1600179130217-9438ff85a6db?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$700'
    },
    {
        title: 'Cebu Canyoneering Adventure',
        rating: '4',
        description: 'Experience the adrenaline rush of canyoneering in the rugged landscapes of Cebu. Dive, swim, and rappel through natural rock formations and cascading waterfalls.',
        image: "https://images.unsplash.com/photo-1573529445738-0271ec9dce68?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$450'
    },
    {
        title: 'Sagada Cave Exploration',
        rating: '4',
        description: 'Embark on a thrilling cave exploration adventure in Sagada. Navigate through underground rivers, crawl through narrow passages, and marvel at the stunning rock formations.',
        image: "https://images.unsplash.com/photo-1581533085113-66be0b5dd3ae?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$300'
    },
    {
        title: 'Palawan Island Hopping',
        rating: '4',
        description: 'Hop on a boat and explore the enchanting islands of Palawan. Discover hidden coves, vibrant coral reefs, and pristine white sand beaches.',
        image: "https://images.unsplash.com/photo-1582745778441-ec7fd31cb647?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$550'
    },
    {
        title: 'Boracay Parasailing Experience',
        rating: '4',
        description: 'Soar above the azure waters of Boracay on an exhilarating parasailing adventure. Enjoy panoramic views of the island and feel the thrill of flying high above the sea.',
        image: "https://images.unsplash.com/photo-1572469675459-d55ad2777484?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$250'
    },
    {
        title: 'Camiguin Island Trekking',
        rating: '4',
        description: 'Trek through the lush jungles and volcanic landscapes of Camiguin Island. Discover hidden waterfalls, hot springs, and ancient ruins along the way.',
        image: "https://images.unsplash.com/photo-1582925589628-125aca3242e5?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$400'
    },
    {
        title: 'Davao Zip Line Adventure',
        rating: '4',
        description: 'Experience the thrill of zip-lining through the canopy of Davao\'s lush rainforests. Enjoy breathtaking views of the surrounding landscape as you soar through the air.',
        image: "https://images.unsplash.com/photo-1544453224-6d0eb03d3cc1?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$150'
    },
    {
        title: 'Batanes Bike Tour',
        rating: '4',
        description: 'Explore the scenic landscapes of Batanes on a thrilling bike tour. Pedal through rolling hills, rugged coastlines, and picturesque villages.',
        image: "https://images.unsplash.com/photo-1560152890-b6b520f4e9a3?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$300'
    },
    {
        title: 'Siquijor Island Hopping',
        rating: '4',
        description: 'Hop on a boat and explore the mystical islands of Siquijor. Discover secluded beaches, natural pools, and enchanting waterfalls.',
        image: "https://images.unsplash.com/photo-1562784482-92540f24964e?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$350'
    },
    {
        title: 'Bohol Chocolate Hills Tour',
        rating: '4',
        description: 'Visit the iconic Chocolate Hills of Bohol and marvel at their unique geological formations. Explore lush greenery, wildlife sanctuaries, and historic landmarks.',
        image: "https://images.unsplash.com/photo-1598917419000-bd9c8b5948f5?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$250'
    },
    {
        title: 'Dumaguete Dolphin Watching',
        rating: '4',
        description: 'Embark on an exciting dolphin watching adventure off the coast of Dumaguete. Get up close and personal with playful dolphins in their natural habitat.',
        image: "https://images.unsplash.com/photo-1601977570628-4c6305eae289?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$200'
    },
    {
        title: 'Anilao Diving Expedition',
        rating: '4',
        description: 'Dive into the crystal-clear waters of Anilao and discover a vibrant underwater world. Explore colorful coral reefs, diverse marine life, and spectacular dive sites.',
        image: "https://images.unsplash.com/photo-1581880662824-29a916254544?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$400'
    },
    {
        title: 'Cagayan de Oro Whitewater Rafting',
        rating: '4',
        description: 'Experience the thrill of whitewater rafting on the rapids of Cagayan de Oro River. Navigate through exciting twists and turns as you conquer the raging waters.',
        image: "https://images.unsplash.com/photo-1614346533581-bb3b5d5cb40f?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$300'
    },
    {
        title: 'Batangas Beach Camping',
        rating: '4',
        description: 'Camp under the stars on the pristine beaches of Batangas. Enjoy bonfires, stargazing, and the soothing sounds of the ocean waves.',
        image: "https://images.unsplash.com/photo-1557899366-3cc8c3f40a97?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$150'
    },
    {
        title: 'Vigan Heritage Walking Tour',
        rating: '4',
        description: 'Step back in time with a walking tour of Vigan\'s UNESCO World Heritage-listed city center. Explore colonial-era streets, ancestral houses, and historic landmarks.',
        image: "https://images.unsplash.com/photo-1618683400116-75b2298b63c8?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$100'
    },
    {
        title: 'Lake Sebu Zipline Adventure',
        rating: '4',
        description: 'Soar above the scenic landscapes of Lake Sebu on a thrilling zipline adventure. Enjoy panoramic views of the lake, waterfalls, and lush forests below.',
        image: "https://images.unsplash.com/photo-1570759611302-169bc14c2f58?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1000&fit=max",
        price: '$200'
    }
    // Add more adventures here...
];
 // Pagination properties
 currentPage = 1;
 pageSize = 12;

 get totalPages(): number {
   return Math.ceil(this.artAndArchitectureArray.length / this.pageSize);
 }

 get paginatedData(): any[] {
   const startIndex = (this.currentPage - 1) * this.pageSize;
   const endIndex = startIndex + this.pageSize;
   return this.artAndArchitectureArray.slice(startIndex, endIndex);
 }

 onPageChange(pageNumber: number): void {
  // Assign the page number to currentPage
  this.currentPage = pageNumber;
}
}
