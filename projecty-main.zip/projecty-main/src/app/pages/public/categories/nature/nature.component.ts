import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { BookingcardComponent } from '../../../../components/bookingcard/bookingcard.component';
import { PaginationComponent } from '../../../../components/pagination/pagination.component';

@Component({
  selector: 'app-nature',
  standalone: true,
  imports: [CommonModule, BookingcardComponent, PaginationComponent],
  templateUrl: './nature.component.html',
  styleUrl: './nature.component.scss'
})
export class NatureComponent {
  foodDataArray: any[] = [
    {
      title: 'Cebu\'s Tasty Treasures',
      rating: 4.8,
      description: 'Discover the delicious flavors of Cebu with these mouthwatering local delicacies.',
      image: "cebu_tasty_treasures.jpg",
      price: '$10'
  },
  {
      title: 'Batangas Bites & Sips',
      rating: 4.5,
      description: 'Savor the unique tastes of Batangas through its delectable dishes and refreshing beverages.',
      image: "batangas_bites_sips.jpg",
      price: '$12'
  },
  {
      title: 'Pampanga Palate Pleasers',
      rating: 4.7,
      description: 'Treat your taste buds to the irresistible flavors of Pampanga\'s culinary creations.',
      image: "pampanga_palate_pleasers.jpg",
      price: '$15'
  },
  {
      title: 'Davao Delights Discovery',
      rating: 4.6,
      description: 'Embark on a delightful journey through Davao and explore its diverse culinary landscape.',
      image: "davao_delights_discovery.jpg",
      price: '$14'
  },
  {
      title: 'Iloilo\'s Flavorful Finds',
      rating: 4.9,
      description: 'Experience the rich and flavorful dishes that Iloilo has to offer in this culinary adventure.',
      image: "iloilo_flavorful_finds.jpg",
      price: '$11'
  },
  {
      title: 'Bohol\'s Best Bites',
      rating: 4.7,
      description: 'Treat yourself to the best bites in Bohol and indulge in its gastronomic delights.',
      image: "bohol_best_bites.jpg",
      price: '$16'
  },
  {
      title: 'Palawan Palate Paradise',
      rating: 4.8,
      description: 'Explore the culinary paradise of Palawan and experience a taste of its tropical flavors.',
      image: "palawan_palate_paradise.jpg",
      price: '$18'
  },
  {
      title: 'Quezon City Culinary Quest',
      rating: 4.6,
      description: 'Embark on a quest to discover the diverse culinary wonders of Quezon City.',
      image: "quezon_city_culinary_quest.jpg",
      price: '$20'
  },
  {
      title: 'Manila Munchies Marathon',
      rating: 4.9,
      description: 'Join the munchies marathon in Manila and taste your way through the city\'s delicious offerings.',
      image: "manila_munchies_marathon.jpg",
      price: '$22'
  },
  {
      title: 'Tagaytay Tasty Trail',
      rating: 4.7,
      description: 'Hit the tasty trail in Tagaytay and enjoy the scenic views along with some delightful dishes.',
      image: "tagaytay_tasty_trail.jpg",
      price: '$17'
  },
  {
      title: 'Bacolod\'s Flavor Fest',
      rating: 4.8,
      description: 'Join the flavor fest in Bacolod and indulge in its mouthwatering culinary delights.',
      image: "bacolod_flavor_fest.jpg",
      price: '$19'
  },
  {
      title: 'Angeles City Food Frenzy',
      rating: 4.6,
      description: 'Experience a food frenzy in Angeles City with its wide array of delectable dishes.',
      image: "angeles_city_food_frenzy.jpg",
      price: '$13'
  },
  {
      title: 'Zambales Zestful Eats',
      rating: 4.7,
      description: 'Treat yourself to some zestful eats in Zambales and savor its delicious local cuisine.',
      image: "zambales_zestful_eats.jpg",
      price: '$16'
  },
  {
      title: 'Bataan\'s Belly Bliss',
      rating: 4.8,
      description: 'Find belly bliss in Bataan with its mouthwatering selection of local delicacies.',
      image: "bataan_belly_bliss.jpg",
      price: '$18'
  },
  {
      title: 'Sorsogon\'s Savory Secrets',
      rating: 4.7,
      description: 'Uncover Sorsogon\'s savory secrets and taste the delicious dishes it has to offer.',
      image: "sorsogon_savory_secrets.jpg",
      price: '$17'
  },
  {
      title: 'Cagayan de Oro Culinary Cruise',
      rating: 4.9,
      description: 'Embark on a culinary cruise in Cagayan de Oro and explore its diverse food scene.',
      image: "cagayan_de_oro_culinary_cruise.jpg",
      price: '$21'
  },
  {
      title: 'Tacloban Tastes & Treats',
      rating: 4.6,
      description: 'Indulge in Tacloban\'s tasty treats and discover the unique flavors of the region.',
      image: "tacloban_tastes_treats.jpg",
      price: '$14'
  },
];
 // Pagination properties
 currentPage = 1;
 pageSize = 12;

 get totalPages(): number {
   return Math.ceil(this.foodDataArray.length / this.pageSize);
 }

 get paginatedData(): any[] {
   const startIndex = (this.currentPage - 1) * this.pageSize;
   const endIndex = startIndex + this.pageSize;
   return this.foodDataArray.slice(startIndex, endIndex);
 }

 onPageChange(pageNumber: number): void {
  // Assign the page number to currentPage
  this.currentPage = pageNumber;
}

}
