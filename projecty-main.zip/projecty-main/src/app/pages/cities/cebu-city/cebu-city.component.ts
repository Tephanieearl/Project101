import { Component, AfterViewInit} from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cebu-city',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './cebu-city.component.html',
  styleUrl: './cebu-city.component.scss'
})
export class CebuCityComponent implements AfterViewInit {
  
  // Implement AfterViewInit interface to execute code after the view has initialized
  ngAfterViewInit(): void {
    // Define an array of section IDs and their corresponding link selectors
    const sectionLinks = [
      { sectionId: 'attractions', linkSelector: 'a[href="#attractions"]' },
      { sectionId: 'things-to-do', linkSelector: 'a[href="#things-to-do"]' },
      { sectionId: 'about-cebu', linkSelector: 'a[href="#about-cebu"]' }
    ];

    // Loop through the section links array and attach event listeners dynamically
    sectionLinks.forEach(({ sectionId, linkSelector }) => {
      const sectionLink = document.querySelector(linkSelector);
      
      if (sectionLink) {
        sectionLink.addEventListener('click', (event) => this.scrollToSection(event as MouseEvent, sectionId));
      }
    });
  }

  // Define a function to handle scrolling to a specific section
  scrollToSection(event: MouseEvent, sectionId: string) {
    // Prevent the default behavior of the anchor link
    event.preventDefault();
    
    // Find the section by its ID
    const section = document.getElementById(sectionId);

    // Check if the section exists
    if (section) {
      // Scroll to the section smoothly
      section.scrollIntoView({ behavior: 'smooth' });
    }
  }

}
