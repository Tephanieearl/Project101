import { Component, OnInit, Output, EventEmitter,} from '@angular/core';
import { Router, Event, NavigationEnd, RouterOutlet } from '@angular/router';
import { NavbarComponent } from './layouts/public/navbar/navbar.component';
import { initFlowbite } from 'flowbite';
import { FooterComponent } from './layouts/public/footer/footer.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { IStaticMethods } from 'preline/preline';


///window is not defined

declare global {
  interface Window {
    HSStaticMethods: IStaticMethods;
  }
}



@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NavbarComponent, FooterComponent, ScrollingModule,],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'projecty';

  constructor(private router: Router) {}

  

  ngOnInit(): void {

    initFlowbite();
    if (typeof window !== 'undefined') {

      this.router.events.subscribe((event: Event) => {
        if (event instanceof NavigationEnd) {
          setTimeout(() => {
            if (window.HSStaticMethods && typeof window.HSStaticMethods.autoInit === 'function') {
              window.HSStaticMethods.autoInit();
            }
          }, 100);
        }
      });
    }
  }

  @Output() closeModal = new EventEmitter<void>();

  onCloseModal() {
    this.closeModal.emit();
  }

}