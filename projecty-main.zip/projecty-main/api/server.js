import express from 'express';

const app = express()

app.listen(8800, ()=>{
    console.log('backend server is running!')
})